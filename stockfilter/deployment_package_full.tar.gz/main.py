#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主程序入口
支持多种运行模式
"""

import sys
import argparse
from pathlib import Path

from utils.logger import get_logger

logger = get_logger()


def run_scan():
    """运行每日形态扫描"""
    logger.info("开始执行形态扫描...")
    from daily_scan import scan_daily_signals, load_config
    
    config = load_config()
    scan_daily_signals(config)
    logger.info("形态扫描完成")


def run_sync():
    """同步 K 线数据"""
    logger.info("开始同步 K 线数据...")
    from sync_kline_history import sync_all_stocks
    
    sync_all_stocks()
    logger.info("K 线数据同步完成")


def run_update():
    """更新当日 K 线数据"""
    logger.info("开始更新 K 线数据...")
    from update_kline_daily import update_kline_data
    
    update_kline_data()
    logger.info("K 线数据更新完成")


def main():
    parser = argparse.ArgumentParser(description='StockFilter 主程序')
    parser.add_argument('--scan', action='store_true', help='执行形态扫描')
    parser.add_argument('--sync', action='store_true', help='同步 K 线数据')
    parser.add_argument('--update', action='store_true', help='更新 K 线数据')
    
    args = parser.parse_args()
    
    if args.scan:
        run_scan()
    elif args.sync:
        run_sync()
    elif args.update:
        run_update()
    else:
        # 默认执行形态扫描
        run_scan()


if __name__ == '__main__':
    main()
