# Binance 保证金不足问题解决方案

## 问题分析

### 错误信息
```
保证金不足：ETHUSDT - Binance API Error -2019: Margin is insufficient.
保证金不足：BNBUSDT - Binance API Error -2019: Margin is insufficient.
保证金不足：BTCUSDT - Binance API Error -2019: Margin is insufficient.
```

### 根本原因
"Margin is insufficient" 错误表示账户保证金不足以开仓。计算公式：

```
开仓所需保证金 = 订单价值 / 杠杆倍数
订单价值 = 价格 × 数量
```

**示例**：
- ETHUSDT 价格：$3,000
- 计划开仓：1 ETH
- 杠杆：10x
- 所需保证金：$3,000 / 10 = $300

如果账户余额 < $300，就会报错。

## 解决方案

### 方案 1：增加保证金账户余额（推荐）

**操作**：
1. 向保证金账户充值 USDT
2. 建议保持至少 2-3 倍于单次开仓所需的保证金
3. 例如：单次开仓需要$300，建议保持$600-$900 余额

**优点**：
- 立竿见影
- 不影响策略逻辑

**缺点**：
- 需要额外资金

### 方案 2：减小开仓仓位

**修改交易策略代码**：

```python
# 原代码（可能满仓）
position_size = account_balance / price

# 修改为（使用 80% 仓位）
position_size = (account_balance * 0.8) / price

# 或使用固定比例
MAX_POSITION_RATIO = 0.8  # 最大使用 80% 保证金
position_size = (account_balance * MAX_POSITION_RATIO) / price
```

**优点**：
- 降低风险
- 避免满仓操作

**缺点**：
- 单次收益减少

### 方案 3：降低杠杆倍数

**影响**：
- 降低杠杆 → 所需保证金增加 → 可以开更大的仓位
- 但风险也降低

**示例**：
- 10x 杠杆：需要$100 保证金开$1000 的仓位
- 5x 杠杆：需要$200 保证金开$1000 的仓位

### 方案 4：优化开仓时机

**添加保证金检查**：

```python
def check_margin_before_open(symbol, required_margin):
    """开仓前检查保证金是否充足"""
    account_balance = get_account_balance()
    available_margin = account_balance * leverage
    
    # 保留 20% 安全边际
    safety_margin = available_margin * 0.2
    
    if required_margin > (available_margin - safety_margin):
        logger.warning(f"{symbol} 保证金不足，跳过开仓")
        return False
    
    return True

# 使用
if check_margin_before_open(symbol, required_margin):
    open_position(symbol)
else:
    logger.info(f"跳过 {symbol} 开仓")
```

## 立即执行的建议

### 短期（立即执行）
1. **充值保证金账户**：至少$500-$1000 USDT
2. **检查当前持仓**：平掉亏损严重的仓位释放保证金
3. **降低仓位**：修改代码使用 80% 仓位而非满仓

### 中期（本周内）
1. **优化仓位管理代码**：
   - 添加保证金预检查
   - 设置最大仓位限制
   - 保留安全边际

2. **调整杠杆**：
   - 评估当前杠杆是否过高
   - 考虑降低至 5x-10x

3. **添加告警**：
   - 保证金低于阈值时告警
   - 飞书/邮件通知

### 长期（持续优化）
1. **资金管理策略**：
   - 单笔最大亏损限制
   - 每日最大交易次数
   - 总仓位控制

2. **风险控制**：
   - 动态调整仓位
   - 波动率自适应
   - 相关性分析

## 代码修改示例

### 修改位置
假设代码在 `binance-trade-analyzer/scheduler_new.py` 或类似文件

### 修改前
```python
# 可能存在的问题代码
position_size = balance / price  # 满仓
order = client.futures_create_order(
    symbol=symbol,
    side='BUY',
    type='MARKET',
    quantity=position_size
)
```

### 修改后
```python
# 修复后的代码
POSITION_RATIO = 0.8  # 使用 80% 仓位
SAFETY_MARGIN = 0.2   # 保留 20% 安全边际

# 计算可用保证金
available_balance = balance * POSITION_RATIO

# 计算仓位
position_size = available_balance / price

# 开仓前检查
required_margin = (position_size * price) / leverage
if required_margin > (balance * (1 - SAFETY_MARGIN)):
    logger.warning(f"保证金不足，跳过 {symbol}")
    continue

# 下单
order = client.futures_create_order(
    symbol=symbol,
    side='BUY',
    type='MARKET',
    quantity=position_size
)
```

## 监控建议

### 实时监控指标
1. **保证金比率**：维持在 50% 以下
2. **未实现盈亏**：设置预警线
3. **仓位集中度**：单一币种不超过 30%

### 告警阈值
- 🟢 正常：保证金使用率 < 50%
- 🟡 警告：保证金使用率 50%-80%
- 🔴 危险：保证金使用率 > 80%

## 总结

**立即行动**：
1. ✅ 充值保证金账户（最快速）
2. ✅ 修改代码降低仓位至 80%
3. ✅ 添加开仓前保证金检查

**预期效果**：
- 消除 "Margin is insufficient" 错误
- 降低爆仓风险
- 提高策略稳定性
