#!/bin/bash
# 检查并启动 stockfilter-app 容器

SSH_KEY="~/.ssh/stockfilter_key"
SERVER_IP="43.156.242.184"

echo "检查服务器上的容器状态..."

ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 << 'ENDSSH'
set -e

echo "【检查容器状态】"

# 1. 检查容器是否存在
echo "1. 检查所有容器..."
docker ps -a --filter "name=stockfilter-app"

# 2. 如果容器存在，启动它
if docker ps -a --format '{{.Names}}' | grep -q "stockfilter-app"; then
    echo "2. 容器存在，启动容器..."
    docker start stockfilter-app
    sleep 5
else
    echo "2. 容器不存在，创建新容器..."
    cd /root/stockfilter
    
    # 检查 Docker 镜像
    if docker images | grep -q "stockfilter"; then
        echo "找到本地镜像"
    else
        echo "未找到镜像，需要重新构建"
        exit 1
    fi
    
    # 创建容器
    docker run -d \
        --name stockfilter-app \
        --restart unless-stopped \
        -v /root/stockfilter:/app \
        -w /app \
        -e PYTHONPATH=/app \
        stockfilter:latest \
        python3 main.py
    sleep 10
fi

# 3. 检查容器状态
echo "3. 检查容器状态..."
docker ps --filter "name=stockfilter-app"

# 4. 查看日志
echo "4. 查看最近日志..."
docker logs stockfilter-app --tail 50

echo ""
echo "✅ 容器已启动！"
echo ""
echo "查看实时日志：docker logs -f stockfilter-app"
echo "查看容器状态：docker ps --filter name=stockfilter-app"

ENDSSH
