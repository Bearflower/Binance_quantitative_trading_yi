#!/bin/bash
# AKShare 连接问题修复部署脚本（优化版）

set -e

# 配置
SERVER_IP="43.156.242.184"
SERVER_USER="root"
SERVER_PATH="/root/stockfilter"
SSH_KEY="~/.ssh/stockfilter_key"
CONTAINER_NAME="stockfilter-app"

echo "============================================================"
echo "AKShare 连接问题修复部署"
echo "============================================================"
echo ""

# 1. 打包项目
echo "📦 正在打包项目..."
cd /Users/yl/vscode/stockfilter

# 创建部署包（只包含必要的 Python 文件）
tar --exclude='venv' \
    --exclude='data/backtest/baostocks_full' \
    --exclude='data/backtest/baostock' \
    --exclude='*.pyc' \
    --exclude='__pycache__' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='output/*' \
    --exclude='signals/*' \
    --exclude='deployment_package*.tar.gz' \
    -czf deployment_package_fix.tar.gz \
    data/fetcher.py \
    requirements.txt \
    config_v21_final.yaml \
    daily_scan.py \
    utils/ \
    data/*.py \
    data/__init__.py

echo "✅ 打包完成：deployment_package_fix.tar.gz"
echo ""

# 2. 上传到服务器
echo "📤 正在上传到服务器..."
scp -i ~/.ssh/stockfilter_key \
    deployment_package_fix.tar.gz \
    root@43.156.242.184:/tmp/deployment_package_fix.tar.gz

echo "✅ 上传完成"
echo ""

# 3. 在服务器上部署
echo "🚀 正在部署到容器..."
ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 << 'ENDSSH'
set -e

echo "【服务器部署步骤】"

# 1. 备份旧代码
echo "1. 备份旧代码..."
cd /root/stockfilter
BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
if [ -f "data/fetcher.py" ]; then
    cp data/fetcher.py "$BACKUP_DIR/"
    echo "已备份 data/fetcher.py 到 $BACKUP_DIR"
fi

# 2. 解压新代码
echo "2. 解压新代码..."
cd /tmp
mkdir -p deploy_fix
cd deploy_fix
tar -xzf /tmp/deployment_package_fix.tar.gz --strip-components=0

# 3. 复制更新的文件
echo "3. 复制更新的文件到项目目录..."
cp -f /tmp/deploy_fix/data/fetcher.py /root/stockfilter/data/fetcher.py

# 4. 验证文件
echo "4. 验证文件..."
if grep -q "max_retries: int = 5" /root/stockfilter/data/fetcher.py; then
    echo "✅ 新代码已正确复制（检测到 max_retries: int = 5）"
else
    echo "❌ 代码更新可能失败"
    exit 1
fi

# 5. 重启容器
echo "5. 重启容器..."
docker restart stockfilter-app

# 6. 等待容器启动
echo "6. 等待容器启动..."
sleep 10

# 7. 检查容器状态
echo "7. 检查容器状态..."
docker ps --filter "name=stockfilter-app"

# 8. 查看日志
echo "8. 查看最近日志..."
docker logs stockfilter-app --tail 30

echo ""
echo "✅ 部署完成！"
echo ""
echo "查看实时日志：docker logs -f stockfilter-app"
echo "查看错误日志：docker logs stockfilter-app 2>&1 | grep ERROR"
echo "查看 AKShare 相关日志：docker logs stockfilter-app 2>&1 | grep -i akshare"

ENDSSH

# 4. 清理
echo ""
echo "🧹 清理临时文件..."
rm -f deployment_package_fix.tar.gz
ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 "rm -rf /tmp/deploy_fix /tmp/deployment_package_fix.tar.gz"

echo ""
echo "============================================================"
echo "✅ 部署完成！"
echo "============================================================"
echo ""
echo "📝 修复内容总结："
echo "  1. ✅ AKShare 重试次数：3 次 → 5 次"
echo "  2. ✅ 重试延迟：5 秒 → 10 秒（基础）"
echo "  3. ✅ 添加指数退避策略（10s, 20s, 30s...）"
echo "  4. ✅ 添加 30 秒超时处理"
echo "  5. ✅ 增强网络错误分类处理"
echo ""
echo "📊 预期效果："
echo "  - 减少 'Remote end closed connection' 错误"
echo "  - 提高 AKShare 数据获取成功率"
echo "  - 更好的网络错误恢复能力"
echo ""
echo "🔍 验证命令："
echo "  ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 \"docker logs stockfilter-app 2>&1 | grep -i akshare\""
echo ""
echo "📈 监控建议："
echo "  - 未来 24 小时观察错误日志"
echo "  - 对比修复前后的错误数量"
echo ""
