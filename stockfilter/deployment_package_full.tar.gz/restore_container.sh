#!/bin/bash
# stockfilter-app 容器恢复脚本

SSH_KEY="~/.ssh/stockfilter_key"
SERVER_IP="43.156.242.184"

echo "============================================================"
echo "stockfilter-app 容器恢复"
echo "============================================================"
echo ""

ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 << 'ENDSSH'
set -e

echo "【恢复步骤】"

# 1. 检查 Docker 镜像
echo "1. 检查 Docker 镜像..."
docker images | grep stockfilter || echo "未找到 stockfilter 镜像"

# 2. 查找 Dockerfile
echo "2. 查找项目目录..."
cd /root/stockfilter
ls -la | head -20

# 3. 检查 Dockerfile
if [ -f "Dockerfile" ]; then
    echo "3. 找到 Dockerfile，准备构建镜像..."
    cat Dockerfile | head -10
else
    echo "3. 未找到 Dockerfile"
    exit 1
fi

# 4. 构建 Docker 镜像
echo "4. 构建 Docker 镜像..."
docker build -t stockfilter:latest .

# 5. 创建并启动容器
echo "5. 创建并启动容器..."
docker run -d \
    --name stockfilter-app \
    --restart unless-stopped \
    -v /root/stockfilter:/app \
    -w /app \
    -e PYTHONPATH=/app \
    stockfilter:latest \
    python3 main.py

# 6. 等待容器启动
echo "6. 等待容器启动..."
sleep 10

# 7. 检查容器状态
echo "7. 检查容器状态..."
docker ps --filter "name=stockfilter-app"

# 8. 查看日志
echo "8. 查看最近日志..."
docker logs stockfilter-app --tail 50

echo ""
echo "✅ 容器恢复完成！"
echo ""
echo "查看实时日志：docker logs -f stockfilter-app"
echo "查看容器状态：docker ps --filter name=stockfilter-app"

ENDSSH

echo ""
echo "============================================================"
echo "✅ 恢复完成！"
echo "============================================================"
