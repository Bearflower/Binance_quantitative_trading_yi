#!/bin/bash
# 重新构建并部署 stockfilter-app 容器

SSH_KEY="~/.ssh/stockfilter_key"
SERVER_IP="43.156.242.184"

echo "============================================================"
echo "重新构建并部署 stockfilter-app 容器"
echo "============================================================"
echo ""

# 1. 打包项目（包含新的 main.py 和修复的 fetcher.py）
echo "📦 正在打包项目..."
cd /Users/yl/vscode/stockfilter

tar --exclude='venv' \
    --exclude='data/backtest/baostocks_full' \
    --exclude='data/backtest/baostock' \
    --exclude='*.pyc' \
    --exclude='__pycache__' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='output/*' \
    --exclude='signals/*' \
    --exclude='deployment_package*.tar.gz' \
    -czf deployment_package_full.tar.gz \
    .

echo "✅ 打包完成：deployment_package_full.tar.gz"
echo ""

# 2. 上传到服务器
echo "📤 正在上传到服务器..."
scp -i ~/.ssh/stockfilter_key \
    deployment_package_full.tar.gz \
    root@43.156.242.184:/tmp/deployment_package_full.tar.gz

echo "✅ 上传完成"
echo ""

# 3. 在服务器上部署
echo "🚀 正在部署..."
ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 << 'ENDSSH'
set -e

echo "【部署步骤】"

# 1. 停止并删除旧容器
echo "1. 停止并删除旧容器..."
docker stop stockfilter-app 2>/dev/null || true
docker rm stockfilter-app 2>/dev/null || true

# 2. 备份旧代码
echo "2. 备份旧代码..."
cd /root/stockfilter
BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -r . "$BACKUP_DIR/" 2>/dev/null || true
echo "已备份到 $BACKUP_DIR"

# 3. 解压新代码
echo "3. 解压新代码..."
cd /root/stockfilter
rm -rf ./* 2>/dev/null || true
tar -xzf /tmp/deployment_package_full.tar.gz --strip-components=1

# 4. 验证关键文件
echo "4. 验证关键文件..."
if [ -f "main.py" ]; then
    echo "✅ main.py 存在"
else
    echo "❌ main.py 不存在"
    exit 1
fi

if [ -f "data/fetcher.py" ]; then
    if grep -q "max_retries: int = 5" data/fetcher.py; then
        echo "✅ data/fetcher.py 已更新（max_retries=5）"
    else
        echo "⚠️  data/fetcher.py 可能未更新"
    fi
else
    echo "❌ data/fetcher.py 不存在"
    exit 1
fi

# 5. 重新构建 Docker 镜像
echo "5. 重新构建 Docker 镜像..."
docker build -t stockfilter:latest .

# 6. 创建并启动容器
echo "6. 创建并启动容器..."
docker run -d \
    --name stockfilter-app \
    --restart unless-stopped \
    -v /root/stockfilter:/app \
    -w /app \
    -e PYTHONPATH=/app \
    -e PYTHONUNBUFFERED=1 \
    -e LOG_LEVEL=INFO \
    stockfilter:latest \
    python3 main.py --scan

# 7. 等待容器启动
echo "7. 等待容器启动..."
sleep 10

# 8. 检查容器状态
echo "8. 检查容器状态..."
docker ps --filter "name=stockfilter-app"

# 9. 查看日志
echo "9. 查看最近日志..."
docker logs stockfilter-app --tail 50

echo ""
echo "✅ 部署完成！"
echo ""
echo "查看实时日志：docker logs -f stockfilter-app"
echo "查看容器状态：docker ps --filter name=stockfilter-app"

ENDSSH

# 4. 清理
echo ""
echo "🧹 清理临时文件..."
rm -f deployment_package_full.tar.gz
ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 "rm -f /tmp/deployment_package_full.tar.gz"

echo ""
echo "============================================================"
echo "✅ 部署完成！"
echo "============================================================"
echo ""
echo "📝 本次修复内容："
echo "  1. ✅ 添加 main.py 入口文件"
echo "  2. ✅ AKShare 重试次数：3 次 → 5 次"
echo "  3. ✅ 重试延迟：5 秒 → 10 秒（基础）"
echo "  4. ✅ 添加指数退避策略"
echo "  5. ✅ 添加 30 秒超时处理"
echo ""
echo "🔍 验证命令："
echo "  ssh -i ~/.ssh/stockfilter_key root@43.156.242.184 \"docker logs stockfilter-app --tail 100\""
echo ""
