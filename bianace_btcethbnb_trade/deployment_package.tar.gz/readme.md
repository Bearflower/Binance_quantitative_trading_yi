# 币安自动化交易系统

基于 traderule.txt 规则引擎的币安合约自动化交易系统，支持 PM 账户（投资组合保证金账户）。

## 🎯 系统特性

### 核心功能

- ✅ **信号检测** - 基于技术指标和形态识别（第三章）
- ✅ **仓位计算** - 动态仓位管理和杠杆配置（第四章）
- ✅ **风险管理** - 止损止盈和资金管理（第五章）
- ✅ **订单生成** - PM 账户订单模板和参数生成（第六章）
- ✅ **应急处理** - 极端行情和风控机制（第七章）
- ✅ **自动调度** - 每小时整点自动分析（00:00, 01:00, ..., 23:00）
- ✅ **飞书推送** - 重要事件实时通知（只发分析结果，不发执行结果）
- ✅ **交易日报** - 每日 9 点自动发送前一日统计
- ✅ **策略回测** - 多时间框架历史数据回测和绩效评估
- ✅ **量化评分** - v6.12 多维度信号评分系统（趋势、形态、风控）
- ✅ **动态仓位** - v6.13 根据可用保证金自动调整仓位大小（2026-04-10 新增）

### 交易规则

- **信号分级**: S/A/B/C四级，不同级别不同杠杆和仓位系数
- **止损设置**: ATR 动态止损（1.5×ATR）
- **止盈策略**: TP1=4×ATR(25%), TP2=6×ATR(25%) + 吊灯止损 (2.5×ATR 启动，1.5×ATR 回撤)
- **仓位管理**: 仓位系数机制（S 级 50%、A 级 30%、B 级 15%、C 级 5%）
- **风控机制**: 日亏损限额 (5%)、连续亏损限额 (5 笔)、总回撤限额 (15%)

### v6.12 量化评分系统（2026-04-07 最终版）

**前置过滤器**（必须同时满足）：
- ADX ≥ 20（日线级别，14 周期）
- 成交量放大：S 级≥1.8 倍，A 级≥1.5 倍，B/C 级≥1.2 倍
- ATR% 区间：2.0% ~ 4.5%

**评分维度**（简化 3 维度，总分 100 分）：

| 维度 | 权重 | 评分方式 |
|------|------|----------|
| **趋势强度** | 40 | EMA21 斜率归一化 + 价格与 EMA21 距离 |
| **形态质量** | 35 | 阳包阴/阴包阳/突破回踩/背离，连续得分 |
| **动量背离** | 25 | MACD 柱线背离程度 |

**信号等级映射**：
- **S 级**（≥85 分）：仓位 50%，杠杆 5 倍
- **A 级**（≥75 分）：仓位 30%，杠杆 4 倍
- **B 级**（≥65 分）：仓位 15%，杠杆 3 倍
- **C 级**（≥55 分）：仓位 5%，杠杆 2 倍
- **<55 分**：过滤，不开仓

**一票否决项**：
- ❌ 资金费率 > 0.08%
- ❌ 波动率 > 6%（支持币种差异化）
- ❌ 24 小时涨幅 > 25% 或 跌幅 > 20%
- ❌ 数据完整性不足

**币种差异化配置**：
```yaml
BTCUSDT: 波动率阈值 4%, 突破阈值 1.5%
ETHUSDT: 波动率阈值 4.5%, 突破阈值 1.5%
BNBUSDT: 波动率阈值 7%, 突破阈值 2.5%
```

### v6.12 核心改进（2026-04-07 最终版）

**仓位系数机制**：
- S 级信号：仓位系数 50%，杠杆 5 倍
- A 级信号：仓位系数 30%，杠杆 4 倍
- B 级信号：仓位系数 15%，杠杆 3 倍
- C 级信号：仓位系数 5%，杠杆 2 倍

**ATR 动态止损**：
- 止损距离 = 1.5×ATR14
- 更紧凑的止损，提高资金效率

**止盈优化**：
- TP1 = 4.0×ATR，平仓 25%
- TP2 = 6.0×ATR，平仓 25%
- 剩余 50% 仓位使用吊灯止损（2.5×ATR 启动，1.5×ATR 回撤）

**频率控制（v6.12 新增）**：
- ✅ 每日最大总交易数：4 笔（所有等级合计）
- ✅ 单品种每日最大交易数：2 笔
- ✅ 同品种冷却期：12 小时
- ✅ 连续亏损暂停：5 笔亏损暂停 1 天
- ✅ 每日最大亏损限额：25U（500U × 5%）
- ✅ 频率控制器：`services/frequency_controller.py`（自动检查交易限制）

### v6.13 动态仓位调整（2026-04-10 新增）

**核心特性**：
- ✅ **智能降仓** - 保证金不足时自动降低仓位，而不是直接跳过
- ✅ **保留安全垫** - 只使用 80% 可用余额，保留 20% 应对波动
- ✅ **最小阈值保护** - 最小保证金 5U，避免过小仓位导致手续费占比过高
- ✅ **最大限制保护** - 单仓最大 100U，防止过度杠杆

**调整逻辑**：
```
1. 计算可用保证金 = 可用余额 × 0.8（保留 20% 安全垫）
2. 如果 可用保证金 >= 预设保证金：不调整，全额执行
3. 如果 可用保证金 < 预设保证金：
   - 计算调整系数 = 可用保证金 / 预设保证金
   - 调整后保证金 = 预设保证金 × 调整系数
   - 如果 调整后保证金 < 5U：跳过交易
   - 否则：等比缩放仓位，执行交易
```

**调整示例**：

| 场景 | 可用余额 | 预设保证金 | 可用保证金 | 调整系数 | 结果 |
|------|---------|-----------|-----------|---------|------|
| **资金充足** | 100U | 14U | 80U | 100% | 执行 14U ✅ |
| **资金略不足** | 12U | 14U | 9.6U | 69% | 执行 9.6U ✅ |
| **资金严重不足** | 6U | 14U | 4.8U | 34% | 跳过 (<5U) ❌ |

**适用场景**：
- ✅ **200-500U 账户**：强烈推荐（资金紧张时自动降仓）
- ✅ **500-1000U 账户**：推荐（保留安全垫，应对波动）
- ⚠️ **1000U+ 账户**：可选（资金充足，v6.12 已足够）

**新增文件**：
- `services/position_adjuster.py` - 动态仓位调整器
- `config/v613_params.yaml` - v6.13 配置参数
- `scripts/backtest_v613.py` - v6.13 回测模拟器

**部署脚本**：
```bash
bash deploy_v613.sh
```

---

## 📊 回测系统

### v6.12 最终版回测器

**核心特性**：
- ✅ **多时间框架分析** - 日线 +4 小时 +1 小时全量数据
- ✅ **精确指标计算** - 使用真实历史 K 线计算技术指标
- ✅ **吊灯止损追踪** - 2.5×ATR 启动，1.5×ATR 回撤
- ✅ **分批止盈** - TP1(4×ATR, 25%) + TP2(6×ATR, 25%)
- ✅ **信号分级统计** - S/A/B/C四级分别统计绩效

**技术指标**：
- EMA21/55、MACD(12,26,9)、RSI(14)、ATR(14)、Bollinger Bands(20,2)
- ADX(14) - 趋势强度过滤
- 成交量比率、形态识别（阳包阴/阴包阳）

**v6.12 回测结果**（6 个月，2025-10-03 至 2026-04-01）：
- 总交易数：88 笔
- 胜率：62.5%
- 净利润：+285.06%
- 平均盈利：3.239%
- 夏普比率：0.48

### 回测数据流

```
币安 API 
  ↓
fetch_multi_timeframe_data.py (获取数据)
  ↓
data/multi_timeframe_data.json (保存数据) ✅
  ↓
run_backtest_v53_full.py (加载数据)
  ↓
multi_timeframe_backtester_v53_full.py (运行回测)
  ↓
data/backtest_report_v5_3_full.json (回测报告)
```

### 快速回测

```bash
# 1. 获取多时间框架数据（180 天）
python3 scripts/fetch_multi_timeframe_data.py \
  --symbols BTCUSDT,ETHUSDT,BNBUSDT \
  --days 180 \
  --output data/multi_timeframe_data.json

# 2. 运行 v5.3 回测
python3 scripts/run_backtest_v53_full.py \
  --data data/multi_timeframe_data.json \
  --capital 500 \
  --output data/backtest_report_v5_3.json
```

### 回测结果示例（v5.3）

| 指标 | 数值 | 说明 |
|------|------|------|
| **总交易数** | 1221 笔 | ↓ 63%（vs v5.2） |
| **日均交易** | 6.8 笔/天 | 接近目标 3-5 笔/天 |
| **胜率** | 99.0% | 仍然过高，但已改善 |
| **盈亏比** | 1.11 | ↑ 178%（vs v5.2） |
| **收益率** | -0.0% | ↑ 59.8%（vs v5.2） |
| **总盈亏** | +36.7U | ↑ 335.7U（vs v5.2） |

**按信号等级统计**：
- S 级：1203 笔，胜率 99.3%，盈亏 -1.46U
- A 级：18 笔，胜率 83.3%，盈亏 +38.14U

---

## 🚀 快速开始

### 1. 环境配置

```bash
# 安装依赖
pip install -r requirements.txt

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件，填入 API 密钥
```

### 2. 系统部署

#### 部署 v6.12 核心代码（推荐）

```bash
# 部署 v6.12 核心文件（评分引擎 + 仓位管理 + 风险管理 + 频率控制）
bash deploy_v612.sh
```

**部署内容**：
- `core/scoring_engine.py` - v6.12 评分引擎（3 维度评分）
- `core/position_calculator.py` - 分级仓位机制（S/A/B/C）
- `core/risk_manager.py` - ATR 动态止损（1.5×ATR）
- `config/strategy_params.py` - v6.12 配置参数
- `services/frequency_controller.py` - v6.12 频率控制器（新增） ⭐
- `scheduler_new.py` - 集成频率控制逻辑（更新） ⭐

**生效时间**：立即生效（容器自动重启）

**频率控制参数（v6.12）**：
- ✅ 每日最大总交易数：4 笔（所有等级合计）
- ✅ 单品种每日最大交易数：2 笔
- ✅ 同品种冷却期：12 小时
- ✅ 连续亏损暂停：5 笔亏损暂停 1 天
- ✅ 每日最大亏损限额：25U（500U × 5%）

#### 完整项目部署

```bash
# 一键部署到服务器
bash deploy_v53.sh
```

部署后自动启动 Docker 容器，每 3 小时整点执行分析（00:00, 03:00, 06:00, 09:00, 12:00, 15:00, 18:00, 21:00）。

### 3. 查看运行状态

```bash
# 查看容器状态
ssh root@43.156.242.184 "docker ps -f name=binance-trade-analyzer"

# 查看实时日志
ssh root@43.156.242.184 "docker logs -f binance-trade-analyzer"

# 查看最近 100 条日志
ssh root@43.156.242.184 "docker logs --tail 100 binance-trade-analyzer"
```

### 4. v5.3 部署验证

**检查文件版本**：
```bash
# SSH 登录服务器
ssh root@43.156.242.184

# 查看文件修改时间
ls -lh /root/binance-trade-analyzer/core/position_calculator.py
ls -lh /root/binance-trade-analyzer/core/risk_manager.py
ls -lh /root/binance-trade-analyzer/config/strategy_params.py

# 应该显示最新修改时间（部署时间）
```

**验证 v5.3 功能**：
```bash
# 查看容器日志，搜索 v5.3 相关关键词
ssh root@43.156.242.184 "docker logs binance-trade-analyzer | grep -i 'v5.3\\|仓位系数\\|ATR'"
```

**监控交易参数**：
- 开仓数量是否变小（仓位系数生效）
- 止损距离是否合理（2.0×ATR）
- 止盈目标是否扩大（4×/6×ATR）

---

## 📦 核心模块

### 0. 评分引擎模块 (core/scoring_engine.py) - v5.5 新增

```python
from core.scoring_engine import get_scoring_engine

# 获取评分引擎
engine = get_scoring_engine()

# 准备数据
symbol = 'BTCUSDT'
data = {
    'funding_rate': 0.0003,
    'price_change_24h': 0.05,
    'indicators': {
        '1d': {
            'close': [95000, 96000, 97000, 98000, 99000],
            'ema21': [94000, 94500, 95000, 95500, 96000],
            'rsi14': [65],
            'macd': [{'dif': 100, 'dea': 80}, {'dif': 120, 'dea': 90}]
        },
        '4h': {
            'close': [98000],
            'ema21': [97000],
            'klines': [{'high': 99000, 'low': 97000, 'volume': 1000}]
        },
        '1h': {
            'close': [98500],
            'ema21': [98000],
            'atr14': [2000]
        }
    }
}

# 执行评分
result = engine.score(symbol, data)

# 输出结果
print(f"币种：{symbol}")
print(f"总分：{result['score']}")
print(f"等级：{result['grade']}")
print(f"建议仓位：{result['position_ratio']*100:.1f}%")
print(f"得分明细：{result['score_detail']}")
```

**输出示例**：
```
✅ BTCUSDT 评分完成：总分 82.5 (S 级)
  趋势强度：25.5/30 (方向一致性 12.0, EMA 斜率 13.5)
  技术形态：24.0/30 (K 线形态 15.0, 突破 9.0)
  动量指标：18.0/20 (RSI 7.5, MACD 10.5)
  风险控制：15.0/20 (费率 8.0, 涨跌幅 4.0, 波动率 3.0)
  建议仓位系数：0.45 (45%)
```

### 1. 信号检测模块 (core/signal_detector.py)

```python
from core.signal_detector import get_signal_detector
from config.strategy_params import get_params

params = get_params()
detector = get_signal_detector(params)

# 检测交易信号
signals = detector.detect_signals(
    symbol='BTCUSDT',
    klines=kline_data,
    current_time=datetime.now()
)
```

### 2. 仓位计算模块 (core/position_calculator.py) - v5.3 仓位系数

```python
from core.position_calculator import calculate_position
from decimal import Decimal

# v5.3: 根据信号等级自动应用仓位系数
position = calculate_position(
    symbol='BTCUSDT',
    entry_price=Decimal('95000'),
    stop_loss_price=Decimal('93000'),  # ~2.1% 止损
    direction=1,  # 1=多，-1=空
    signal_grade='A'  # S/A/B 三级
)

# v5.3 新增字段
print(f"基础名义价值：{position['base_notional_value']}U")  # 238U
print(f"仓位系数：{position['position_coefficient']:.0%}")  # 30% (A 级)
print(f"实际名义价值：{position['actual_notional_value']}U")  # 71U (238×0.3)
print(f"保证金：{position['margin']}U")  # 14U (71/5)
print(f"杠杆：{position['leverage']}x")  # 5x

# 风险降低效果：从 238U 降至 71U，降低 70%
```

### 3. 风险管理模块 (core/risk_manager.py) - v5.3 ATR 动态止损

```python
from core.risk_manager import (
    calculate_atr_based_stop_loss,
    calculate_take_profit_levels,
    check_trailing_stop_ema21,
    check_trailing_stop_drawdown
)
from decimal import Decimal

# v5.3: ATR 动态止损
atr14 = Decimal('800')  # 1 小时 ATR14
stop_loss_price, stop_distance = calculate_atr_based_stop_loss(
    entry_price=Decimal('95000'),
    direction=1,
    atr14=atr14,
    max_stop_pct=Decimal('0.07')  # 最大 7%
)
print(f"止损距离：{stop_distance} ({stop_distance/Decimal('95000'):.2%})")  # 1600 (2.0×ATR)
print(f"止损价：{stop_loss_price}")  # 93400

# v5.3: 止盈优化（4×/6×ATR）
take_profits = calculate_take_profit_levels(
    entry_price=Decimal('95000'),
    direction=1,
    atr14=atr14,
    signal_grade='A'  # S 级：TP1 平 20%, A 级：TP1 平 30%
)
# TP1: 95000 + 4×800 = 98200
# TP2: 95000 + 6×800 = 100600

# v5.3: 移动止损双机制
# 1. EMA21 跟踪止损
trigger_ema = check_trailing_stop_ema21(
    current_price=Decimal('94000'),
    ema21_value=Decimal('94500'),
    direction=1
)  # True (跌破 EMA21)

# 2. 回撤止损保护
trigger_drawdown = check_trailing_stop_drawdown(
    current_price=Decimal('93000'),
    highest_price=Decimal('95000'),
    atr14=atr14,
    direction=1
)  # True (回撤≥2.5×ATR)
```

### 4. 订单生成模块 (core/order_generator.py)

```python
from core.order_generator import generate_order_template, generate_all_orders

# 生成订单模板
template = generate_order_template(
    symbol='BTCUSDT',
    direction=1,
    entry_price=Decimal('95000'),
    stop_loss_price=Decimal('93000'),
    signal_grade='A',
    position_data=position
)

# 生成所有订单参数
all_orders = generate_all_orders(template, position_qty=position['quantity'])
# all_orders['entry'] - 开仓单
# all_orders['stop_loss'] - 止损单
# all_orders['take_profits'] - 止盈单列表
```

### 5. 应急处理模块 (core/emergency_handler.py)

```python
from core.emergency_handler import check_extreme_market, is_trading_allowed
from decimal import Decimal

# 检查极端行情
is_extreme = check_extreme_market(
    symbol='BTCUSDT',
    price_change_percent=Decimal('5.5')  # 24 小时涨跌幅
)

# 检查是否允许交易
allowed, reason = is_trading_allowed()
if not allowed:
    print(f"交易被禁止：{reason}")
```

---

## 📈 策略回测详细指南

### 基础回测

```python
from backtesting import run_backtest
from datetime import datetime
from decimal import Decimal

# 准备历史数据
historical_data = {
    'BTCUSDT': [...],  # K 线数据列表
    'ETHUSDT': [...],
    'BNBUSDT': [...]
}

# 运行回测
report = run_backtest(
    historical_data=historical_data,
    start_date=datetime(2025, 1, 1),
    end_date=datetime(2025, 12, 31),
    initial_capital=Decimal('500')
)

# 查看结果
print(f"总交易数：{report['summary']['total_trades']}")
print(f"总收益率：{report['summary']['total_return']:.1%}")
print(f"最大回撤：{report['summary']['max_drawdown']:.1%}")
print(f"综合评估：{report['performance_assessment']['overall']}")
```

### 详细回测报告

```python
# 访问详细统计
summary = report['summary']
print(f"胜率：{summary['win_rate']:.1%}")
print(f"盈亏比：{summary['profit_loss_ratio']:.2f}")
print(f"年化收益：{summary['annualized_return']:.1%}")
print(f"夏普比率：{summary['sharpe_ratio']:.2f}")

# 按信号等级统计
for grade, stats in report['grade_statistics'].items():
    print(f"{grade}级：{stats['trades']}笔，胜率{stats['win_rate']:.1%}")

# 查看交易记录
for trade in report['trades'][:10]:  # 前 10 笔
    print(f"{trade['symbol']} {trade['direction']} "
          f"盈亏：{trade['pnl']:.2f}U ({trade['pnl_percent']:.1%})")
```

### 从币安获取历史数据

```python
import requests

def fetch_binance_klines(symbol, interval='1h', limit=1000):
    """从币安获取历史 K 线数据"""
    url = 'https://fapi.binance.com/fapi/v1/klines'
    params = {
        'symbol': symbol,
        'interval': interval,
        'limit': limit
    }
    
    response = requests.get(url, params=params)
    data = response.json()
    
    klines = []
    for k in data:
        kline = {
            'timestamp': datetime.fromtimestamp(k[0] / 1000).isoformat(),
            'open': str(k[1]),
            'high': str(k[2]),
            'low': str(k[3]),
            'close': str(k[4]),
            'volume': str(k[5])
        }
        klines.append(kline)
    
    return klines

# 获取数据
historical_data = {
    'BTCUSDT': fetch_binance_klines('BTCUSDT', interval='1h', limit=2000),
    'ETHUSDT': fetch_binance_klines('ETHUSDT', interval='1h', limit=2000),
    'BNBUSDT': fetch_binance_klines('BNBUSDT', interval='1h', limit=2000)
}
```

---

## 🔔 飞书通知

### 推送场景

系统会在以下场景发送飞书通知：

1. ✅ **检测到交易信号** - 整点分析后检测到 S/A/B 级信号
2. ✅ **执行交易** - 实际开仓/平仓
3. ✅ **停止交易** - 触发风控停止交易
4. ✅ **系统异常** - 分析执行失败

**不会推送的场景**：
- ❌ 未检测到信号（避免频率限制）
- ❌ 正常的整点分析完成

### 日报功能

每天早上 9 点自动发送前一天的交易日报：

```
📊 交易日报 (2026-04-01)

📈 执行统计:
├─ 检测次数：24 次
├─ 有效信号：3 个
├─ 成功执行：2 笔
└─ 胜率：50.0%
├─ 盈利：1 笔
└─ 亏损：1 笔
```

---

## ⚙️ 配置说明

### 策略参数 (config/strategy_params.json)

```json
{
  "account": {
    "single_position_margin": "30",
    "max_total_margin": "100"
  },
  "position_sizing": {
    "leverage_by_grade": {
      "S": 5,
      "A": 4,
      "B": 3
    }
  },
  "risk_management": {
    "stop_loss_pct": "0.02",
    "take_profit_levels": {
      "tp1_ratio": "0.3",
      "tp1_multiplier": "1.5",
      "tp2_ratio": "0.3",
      "tp2_multiplier": "2.5"
    }
  }
}
```

### 环境变量 (.env)

```bash
# 币安 API 密钥
BINANCE_API_KEY=your_api_key
BINANCE_SECRET_KEY=your_secret_key

# 飞书 Webhook
LARK_WEBHOOK_URL=your_webhook_url

# 数据库连接
DATABASE_URL=postgresql://user:pass@host:5432/dbname
```

---

## 📁 项目结构

```
bianace_btcethbnb_trade/
├── core/                      # 核心模块
│   ├── signal_detector.py    # 信号检测
│   ├── position_calculator.py # 仓位计算
│   ├── risk_manager.py       # 风险管理
│   ├── order_generator.py    # 订单生成
│   └── emergency_handler.py  # 应急处理
├── backtesting/              # 回测模块
│   ├── multi_timeframe_backtester_v53_full.py  # v5.3 回测器
│   ├── technical_indicators.py  # 技术指标
│   └── strategy_backtester.py
├── scripts/                  # 脚本模块
│   ├── fetch_multi_timeframe_data.py  # 数据获取
│   └── run_backtest_v53_full.py       # 回测执行
├── reporting/                # 报告模块
│   ├── performance_reporter.py
│   └── strategy_reminder.py
├── services/                 # 服务模块
│   ├── auto_executor.py
│   └── trade_statistics.py
├── utils/                    # 工具模块
│   ├── binance_api.py
│   ├── lark_notifier.py
│   └── technical_indicators.py
├── config/                   # 配置文件
│   ├── strategy_params.json
│   └── settings.py
├── data/                     # 数据文件
│   ├── multi_timeframe_data.json
│   └── backtest_report_v5_3.json
├── scheduler_new.py          # 调度器
├── deploy_v53.sh            # 部署脚本
└── README.md                # 项目文档
```

---

## ⏰ 定时任务

系统包含 2 个定时任务：

| 任务 | 执行时间 | 说明 |
|------|----------|------|
| 每小时分析 | 每小时整点 | 行情分析、信号检测、自动交易 |
| 每日日报 | 每天早上 9 点 | 发送前一天的交易统计报告 |

---

## 🧪 测试

### 单元测试

```bash
# 核心模块测试
ssh root@43.156.242.184 "docker exec binance-trade-analyzer python /app/test_modules.py"

# 集成测试
ssh root@43.156.242.184 "docker exec binance-trade-analyzer python /app/test_integration.py"
```

### 回测测试

```python
# 使用历史数据回测
from backtesting import run_backtest
from datetime import datetime
from decimal import Decimal

historical_data = load_your_data()
report = run_backtest(
    historical_data=historical_data,
    start_date=datetime(2025, 1, 1),
    end_date=datetime(2025, 12, 31),
    initial_capital=Decimal('500')
)

print(f"回测完成：{report['summary']['total_trades']}笔交易")
```

---

## ❓ 常见问题

### Q1: 如何修改策略参数？

编辑 `config/strategy_params.json`，然后重新部署：

```bash
bash deploy_v53.sh
```

### Q2: 如何查看飞书推送配置？

编辑 `.env` 文件中的 `LARK_WEBHOOK_URL`，然后重启容器：

```bash
ssh root@43.156.242.184 "docker restart binance-trade-analyzer"
```

### Q3: 回测需要多少数据？

建议至少 3-6 个月的历史数据，理想是 1-2 年，包含不同市场环境。

### Q4: 如何优化策略参数？

使用回测功能进行参数优化：

```python
from backtesting import StrategyBacktester
from itertools import product

# 遍历参数组合
for margin, leverage in product([30, 40, 50], [3, 4, 5]):
    # 设置参数并回测
    # 选择夏普比率最高的组合
```

### Q5: 如何获取多时间框架数据？

```bash
python3 scripts/fetch_multi_timeframe_data.py \
  --symbols BTCUSDT,ETHUSDT,BNBUSDT \
  --days 180 \
  --output data/multi_timeframe_data.json
```

---

## ⚠️ 风险提示

1. **市场风险**: 加密货币市场波动大，存在亏损风险
2. **技术风险**: 系统故障、网络延迟等可能导致交易失败
3. **过拟合风险**: 回测结果不代表未来表现
4. **资金管理**: 建议使用小资金测试，确认稳定后再增加投入

---

## 📚 v5.3 相关文档

### 核心文档

- [`虚拟货币合约交易系统化操作规范 v5.3.md`](虚拟货币合约交易系统化操作规范 v5.3.md) - 完整交易规范
- [`v5.3 系统整改完成报告.md`](v5.3 系统整改完成报告.md) - 整改总结
- [`v5.3 部署成功报告.md`](v5.3 部署成功报告.md) - 部署报告

### 技术文档

- [`规范 v5.3 对照报告 - 第三四五章.md`](规范 v5.3 对照报告 - 第三四五章.md) - 规范符合度检查
- [`v5.3 仓位管理和风险管理整改报告.md`](v5.3 仓位管理和风险管理整改报告.md) - 核心模块整改
- [`v5.3 回测成功报告.md`](v5.3 回测成功报告.md) - 回测验证

### 部署脚本

- [`deploy_v53_core.sh`](deploy_v53_core.sh) - v5.3 核心代码部署脚本
- [`run_full_backtest_v53.py`](run_full_backtest_v53.py) - 完整回测脚本

---

## 📝 更新日志

### v6.13 (2026-04-10) - 动态仓位调整

**核心改进**：
- ✅ **动态仓位调整器** - 根据可用保证金自动缩放仓位（方案 A + 最小阈值）
- ✅ **保留安全垫** - 只使用 80% 可用余额，保留 20% 应对波动
- ✅ **最小阈值保护** - 避免过小仓位（<5U），防止手续费占比过高
- ✅ **最大限制保护** - 单仓最大 100U，防止过度杠杆
- ✅ **详细日志** - 记录调整前后对比，便于追踪
- ✅ **向后兼容** - 不影响 v6.12 的频率控制机制

**新增文件**：
- `services/position_adjuster.py` - 动态仓位调整器（235 行）
- `config/v613_params.yaml` - v6.13 配置参数（85 行）
- `scripts/backtest_v613.py` - v6.13 回测模拟器（575 行）
- `docs/reports/v613 动态仓位调整更新报告.md` - 完整更新报告（350+ 行）
- `docs/reports/v613 回测报告.md` - 回测对比报告
- `deploy_v613.sh` - 自动化部署脚本

**修改文件**：
- `scheduler_new.py` - 集成动态仓位调整逻辑（约 50 行修改）
- `README.md` - 添加 v6.13 功能说明

**核心算法**：
```python
# 1. 计算可用保证金（保留 20% 安全垫）
usable_balance = available_balance × 0.8

# 2. 资金充足？不调整
if usable_balance >= required_margin:
    return position_params  # 全额执行

# 3. 资金不足？计算调整系数
adjustment_ratio = usable_balance / required_margin
adjusted_margin = required_margin × adjustment_ratio

# 4. 检查最小阈值
if adjusted_margin < 5U:
    return None  # 跳过交易

# 5. 应用调整（等比缩放）
adjusted_position['quantity'] = original_quantity × adjustment_ratio
adjusted_position['margin'] = adjusted_margin
```

**调整示例**：
- **资金充足 (100U)**：可用 80U >= 14U → 不调整，执行 14U
- **资金略不足 (12U)**：可用 9.6U < 14U → 调整至 9.6U (69%)
- **资金严重不足 (6U)**：可用 4.8U < 5U → 跳过交易

**部署状态**：
- ✅ 2026-04-10 完成开发和测试
- ✅ 2026-04-10 成功部署到生产服务器
- ✅ 容器已重启，v6.13 功能已生效

**预期效果**：
| 场景 | v6.12 | v6.13 | 改善 |
|------|-------|-------|------|
| **资金充足 (100U+)** | 执行 | 执行 | = 相同 |
| **资金略不足 (50-100U)** | ❌ 跳过 | ✅ 执行 (60-90%) | ↑ 成功率 |
| **资金紧张 (20-50U)** | ❌ 跳过 | ✅ 执行 (30-60%) | ↑ 机会 |
| **资金严重不足 (<20U)** | ❌ 跳过 | ❌ 跳过 | = 相同 |

**推荐部署**：
- ✅ **200-500U 账户**：强烈推荐（效果最明显）
- ✅ **500-1000U 账户**：推荐（可调整阈值至 8-10U）
- ⚠️ **1000U+ 账户**：可选（资金充足，v6.12 已足够）

### v5.5 (2026-04-07) - 量化评分系统

**核心改进**：
- ✅ **量化评分系统** - 四大维度 100 分制（趋势 30+ 形态 30+ 动量 20+ 风控 20）
- ✅ **趋势强度评分** - 多时间框架方向一致性（15 分）+ EMA 斜率（15 分，使用 numpy.polyfit）
- ✅ **技术形态评分** - K 线形态识别（21 分）+ 支撑阻力突破（9 分）
- ✅ **动量指标评分** - RSI 评分（8 分）+ MACD 评分（12 分）
- ✅ **风险控制评分** - 资金费率（8 分）+ 涨跌幅（6 分）+ 波动率（6 分）
- ✅ **一票否决机制** - 5 项风险控制（资金费率、波动率、涨跌幅、数据完整性）
- ✅ **智能仓位管理** - 线性映射公式 + 等级限制（S 级 40-60%，A 级 30-50%）
- ✅ **币种差异化配置** - BTC/ETH/BNB 不同的波动率和突破阈值
- ✅ **向后兼容** - 保留旧评分逻辑作为 fallback

**新增文件**：
- `core/scoring_engine.py` - 评分引擎核心类（920 行）
- `config/scoring_params.yaml` - 评分系统配置文件（90 行）

**修改文件**：
- `core/signal_detector.py` - 集成新评分系统

**技术亮点**：
- 使用 numpy 进行线性回归计算 EMA 斜率
- 支持币种差异化配置（BTC 4%, ETH 4.5%, BNB 7% 波动率阈值）
- 详细日志输出（每个维度的得分明细）
- 单次评分耗时 < 50ms

**实施状态**：
- ✅ 阶段一：核心功能完成（20 小时）
- ⏳ 阶段二：集成与测试（待实施）
- ⏳ 阶段三：回测与文档（待实施）

**预期效果**：
- S 级信号（≥75 分）胜率 > 55%
- A 级信号（60-74 分）胜率 > 45%
- 整体夏普比率 > 1.0

### v5.3 (2026-04-02) - 全仓自动化版

**核心改进**：
- ✅ **仓位系数机制** - S 级 50%、A 级 30%、B 级 20%
- ✅ **ATR 动态止损** - 2.0×ATR（更紧凑）
- ✅ **止盈优化** - TP1=4×ATR, TP2=6×ATR（空间扩大 33%）
- ✅ **移动止损双机制** - EMA21 跟踪 + 2.5×ATR 回撤保护
- ✅ **规范符合度** - 第四章 100%、第五章 100%

**配置优化**（2026-04-02 17:33）：
- ✅ **单仓保证金** - 30U → 15U（↓50%，适应小资金账户）
- ✅ **运行频率** - 每小时 → 每 3 小时（00:00, 03:00, 06:00, 09:00, 12:00, 15:00, 18:00, 21:00）

**部署状态**：
- ✅ 2026-04-02 17:05 成功部署到生产服务器
- ✅ 2026-04-02 17:33 配置优化部署
- ✅ 容器已重启，立即生效
- ✅ 风险降低 50-80%（根据信号等级）

**效果对比**：
| 指标 | 旧版 | v5.3 | 改善 |
|------|------|------|------|
| S 级仓位 | 100% | 50% | ↓ 50% |
| A 级仓位 | 100% | 30% | ↓ 70% |
| 单仓保证金 | 30U | 15U | ↓ 50% |
| 止损距离 | 2.5×ATR | 2.0×ATR | ↓ 20% |
| 止盈空间 | 3-5×ATR | 4-6×ATR | ↑ 33% |
| 运行频率 | 24次/日 | 8次/日 | ↓ 67% |
| 交易频率 | ~9笔/日 | ~3笔/日 | ↓ 67% |

### v5.2 (2026-03-25)

- ✅ 多时间框架回测系统
- ✅ 动态止损止盈
- ✅ 信号分级统计

### v1.0.0 (2026-04-01)

- ✅ 完成核心交易模块（信号检测、仓位计算、风险管理、订单生成、应急处理）
- ✅ 实现自动调度（每小时整点执行）
- ✅ 集成飞书推送（重要事件通知）
- ✅ 实现交易日报（每天早上 9 点发送）
- ✅ 实现策略回测功能
- ✅ 一键部署到 Docker

---

## 📜 许可证

MIT License

## 👥 联系方式

- 项目问题请提 Issue
- 技术交流请联系开发者
